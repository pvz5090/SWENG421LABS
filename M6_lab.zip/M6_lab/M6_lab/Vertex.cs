﻿using System;
using System.Collections.Generic;
using System.Drawing.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M6_lab
{
    internal class Vertex : Drawing, ICloneable
    {
        private int vertex_ID;
        private int x_coordinate;
        private int y_coordinate;

        public Vertex(int x, int y)
        {
            vertex_ID = GraphManager.getNextVertexID();
            GraphManager.incrementNextVertexID();
            x_coordinate = x;
            y_coordinate = y;
        }

        public Vertex(Vertex otherVertex)
        {
            vertex_ID = GraphManager.getNextVertexID();
            GraphManager.incrementNextVertexID();

            x_coordinate = otherVertex.x_coordinate;
            y_coordinate = otherVertex.y_coordinate;
        }


        public object Clone()
        {
            return new Vertex(this);
        }

        public void drawing(Graphics g, Color c, int s)
        {
            Pen pen = new Pen(c);
            Rectangle r = new Rectangle(this.getX() - s, this.getY() - s, 2 * s, 2 * s);
            g.DrawEllipse(pen, r);
        }

        public int getX()
        {
            return x_coordinate;
        }

        public void setX(int x)
        {
            this.x_coordinate = x;
        }

        public int getY()
        {
            return y_coordinate;
        }

        public void setY(int y)
        {
            this.y_coordinate = y;
        }

        public int getVertexID()
        {
            return vertex_ID;
        }

        public void setVertexID(int id) {vertex_ID = id;}

        public override string ToString()
        {
            return vertex_ID.ToString();
        }
    }
}

namespace p2
{
    public class BubblesortUtility<T> : SortUtility<T> where T : IComparable {
        public BubblesortUtility() : base("bubblesort") {}
    }
}
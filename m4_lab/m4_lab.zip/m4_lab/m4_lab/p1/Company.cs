﻿using p2;
using System;
namespace p1;
public class Company
{
    public SortUtility<ProductIF> sortUtility;
}